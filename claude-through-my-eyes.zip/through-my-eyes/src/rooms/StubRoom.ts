import * as THREE from 'three';
import { BaseRoom } from './Room';
import { buildShell } from './shell';
import { FONT, PALETTE, mat, rbox, signPlane, wrap } from '../world/materials';
import { RoomId } from '../config';

/**
 * Placeholder room so every doorway works from day one.
 * It shows the room's plan on the wall and a "complete task" button so the
 * full flow (attempt -> support -> results) can be tested.
 * Replace by extending BaseRoom directly (see colourBlindness for an example).
 */
export class StubRoom extends BaseRoom {
  constructor(id: RoomId, private plan: string[]) { super(id); }

  protected build(): void {
    const s = this.scene;
    buildShell(s, this.colliders, { accentWall: this.info.accent });
    const sign = signPlane(3.2, 2, 300, (c, W, H) => {
      c.fillStyle = PALETTE.cream;
      c.beginPath(); c.roundRect(0, 0, W, H, 36); c.fill();
      c.fillStyle = PALETTE.charcoal;
      c.font = `700 64px ${FONT}`;
      c.fillText(`${this.info.icon}  ${this.info.title}`, 50, 100);
      c.font = `36px ${FONT}`;
      c.fillStyle = '#4A4A50';
      c.fillText('Under construction. The plan for this room:', 50, 160);
      let y = 225;
      c.font = `32px ${FONT}`;
      c.fillStyle = PALETTE.charcoal;
      for (const p of this.plan) for (const [i, l] of wrap(c, p, W - 140).entries()) { c.fillText((i ? '    ' : '•  ') + l, 50, y); y += 42; }
    }, 0.3);
    sign.position.set(0, 1.7, -3.89);
    s.add(sign);

    const pedestal = rbox(0.5, 0.9, 0.5, PALETTE.wood, 0.05);
    pedestal.position.set(0, 0.45, -1);
    s.add(pedestal);
    this.colliders.addMesh(pedestal);
    const btn = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 0.06, 24), mat(this.info.accent, { emissive: this.info.accent, emissiveIntensity: 0.4 }));
    btn.position.set(0, 0.93, -1);
    s.add(btn);
    this.ctx.addClickable(btn, () => this.ctx.complete());
    this.ctx.setTaskText('Placeholder: click the glowing button to complete the task');
  }

  resetTask(): void { this.ctx.setTaskText('Placeholder: click the button again (support mode)'); }
}
