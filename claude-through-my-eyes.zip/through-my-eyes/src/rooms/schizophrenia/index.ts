import { StubRoom } from '../StubRoom';

/*
 * TODO (P2, handle with care): Schizophrenia room
 * Scene: calm office waiting room; a job application form (ctx.showPanel).
 * Task: fill in 5 short fields correctly from an instruction card.
 * Condition: quiet voices panned around the listener ("you'll get it wrong",
 *   the visitor's name whispered). Rarely, a word on the card changes, or a
 *   shadow appears at the edge of vision.
 *   NO jump scares, monsters, horror music or violence.
 * Support: quieter voices, a calm receptionist giving clear steps, extra time.
 */
export class SchizophreniaRoom extends StubRoom {
  constructor() {
    super('schizophrenia', [
      'Calm waiting room with a job application form',
      'Task: fill in 5 fields from an instruction card',
      'Condition: quiet voices commenting; subtle changes to the card',
      'Support: calm, clear guidance and a quiet space',
    ]);
  }
}
