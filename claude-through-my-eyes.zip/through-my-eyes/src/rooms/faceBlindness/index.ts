import { StubRoom } from '../StubRoom';

/*
 * TODO (P1): Face blindness room
 * Scene: house party, 10 people from primitives (capsule body, sphere head) all
 *   sharing ONE CanvasTexture face. Vary height, width, shirt colour, hair,
 *   glasses, hats. Gentle idle sway.
 * Round 1: a text from Sam ("I'm tall, glasses, green jacket"). Click him.
 * Round 2: "Spilled a drink, borrowed a jacket!" Clothes swap. Click people to
 *   hear a greeting (ctx.audio.speak with a different pitch per person) and
 *   recognise Sam's voice.
 * Support: name tags (Sprites) and people introduce themselves by name.
 */
export class FaceBlindnessRoom extends StubRoom {
  constructor() {
    super('faceBlindness', [
      'House party with 10 people who all share one face',
      'Round 1: find Sam from his text description',
      'Round 2: Sam changed jackets; recognise him by voice',
      'Support: name tags and introductions',
    ]);
  }
}
