import { StubRoom } from '../StubRoom';

/*
 * TODO (P1): Dyslexia room
 * Scene: small café counter with a waiter figure (primitives).
 * Task: the waiter asks for an item; find it on the menu and pick its price
 *   (multiple-choice buttons) before the patience bar empties.
 * Condition: menu is an HTML panel (ctx.showPanel). Every ~300ms a share of
 *   letters swap with neighbours and shift a few px; tight letter spacing, busy
 *   low-contrast background. Legible with effort, not impossible.
 * Support (setAccessible(true)): larger font, wide spacing, cream background,
 *   clear sections, "Read aloud" button (ctx.audio.speak).
 * Call ctx.complete() when the right price is picked.
 */
export class DyslexiaRoom extends StubRoom {
  constructor() {
    super('dyslexia', [
      'Café counter with a waiter',
      'Task: find the item on a menu and pick its price before the waiter loses patience',
      'Condition: letters swap and drift; tight, low-contrast text',
      'Support: clear spacing, larger font and read-aloud',
    ]);
  }
}
