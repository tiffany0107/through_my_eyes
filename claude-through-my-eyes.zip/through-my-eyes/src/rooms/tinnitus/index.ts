import { StubRoom } from '../StubRoom';

/*
 * TODO (P1): Tinnitus room
 * Scene: busy coffee shop with an order pickup counter.
 * Task: the barista calls names (ctx.audio.speak / clips in /public/audio);
 *   press "That's me!" when your name is called. Two decoys sound similar.
 * Condition: ctx.audio.tone(6000, 0.04, 40) plus ctx.audio.murmur(0.08).
 *   The tone is hard-capped in AudioManager. Add a dedicated tone slider.
 * Support: the tone stays (tinnitus doesn't switch off) but captions and an
 *   "Order ready" screen show the names.
 * Remember to stop sounds in exit().
 */
export class TinnitusRoom extends StubRoom {
  constructor() {
    super('tinnitus', [
      'Busy coffee shop, waiting for your order',
      'Task: react when the barista calls your name',
      'Condition: constant ringing over café noise',
      'Support: captions and an "Order ready" screen',
    ]);
  }
}
