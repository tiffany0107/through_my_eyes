// All copy lives here so the team can edit text without touching scene code.
// [VERIFY] = check and cite before demo. [QUOTE NEEDED] = replace with a real,
// permission-given quote from someone with lived experience. Never invent quotes.

export type RoomId =
  | 'colourBlindness'
  | 'tunnelVision'
  | 'dyslexia'
  | 'faceBlindness'
  | 'tinnitus'
  | 'schizophrenia'
  | 'reflection';

export interface RoomInfo {
  id: RoomId;
  title: string;
  icon: string;
  accent: string; // Okabe-Ito: distinguishable for colour-blind visitors
  tagline: string;
  quote: string;
  quoteBy: string;
  stat: string;
  source: string;
  task: string;
  supportTask: string;
  warning?: string;
  note?: string;
  helped: string;
  action: string; // shown in the reflection room
}

export const ROOMS: RoomInfo[] = [
  {
    id: 'colourBlindness',
    title: 'Colour blindness',
    icon: '🎨',
    accent: '#E69F00',
    tagline: 'When red and green look the same',
    quote: '[QUOTE NEEDED] A short first-person line about shopping, maps or cooking.',
    quoteBy: '— Name, age',
    stat: 'About 1 in 12 men and 1 in 200 women have colour vision deficiency.',
    source: 'Colour Blind Awareness (colourblindawareness.org)',
    task: 'Pick 5 ripe (red) tomatoes and drop them in your basket.',
    supportTask: 'Same task, now with ripeness tags on the produce.',
    helped: 'Labels and symbols carried the meaning, not colour alone.',
    action: "Don't rely on colour alone: add labels, icons or patterns.",
  },
  {
    id: 'tunnelVision',
    title: 'Tunnel vision',
    icon: '👁️',
    accent: '#56B4E9',
    tagline: 'Seeing the world through a keyhole',
    quote: '[QUOTE NEEDED] A short first-person line about losing peripheral vision.',
    quoteBy: '— Name, age',
    stat: '[VERIFY] Glaucoma, a common cause of tunnel vision, is a leading cause of irreversible blindness worldwide.',
    source: '[VERIFY] World Health Organization, World report on vision',
    task: 'Find your keys somewhere in this living room.',
    supportTask: 'Same task, with a tidy room, a high-contrast key tag and a sound cue.',
    helped: 'A tidy, predictable space, high contrast and a sound cue.',
    action: 'Keep shared spaces tidy and predictable; use high contrast.',
  },
  {
    id: 'dyslexia',
    title: 'Dyslexia',
    icon: '📖',
    accent: '#009E73',
    tagline: 'When reading takes everything you have',
    quote: '[QUOTE NEEDED]',
    quoteBy: '— Name, age',
    stat: '[VERIFY] Dyslexia affects an estimated 1 in 10 people.',
    source: '[VERIFY] British Dyslexia Association',
    task: 'Order the item the waiter asks for before they lose patience.',
    supportTask: 'Same task, with clear spacing and read-aloud.',
    note: 'Dyslexia is mainly about how the brain processes language. This shows the extra effort, not literally what people see.',
    helped: 'Clear spacing, a readable font and read-aloud.',
    action: 'Use clear fonts and spacing, and offer audio alternatives.',
  },
  {
    id: 'faceBlindness',
    title: 'Face blindness',
    icon: '👥',
    accent: '#CC79A7',
    tagline: 'A room full of strangers, every time',
    quote: '[QUOTE NEEDED]',
    quoteBy: '— Name, age',
    stat: '[VERIFY] Prosopagnosia may affect around 1 in 50 people.',
    source: '[VERIFY] cite source',
    task: 'Find your friend Sam at the party.',
    supportTask: 'Same task, with name tags.',
    helped: 'Name tags, and people introducing themselves.',
    action: 'Introduce yourself by name, even to people you know.',
  },
  {
    id: 'tinnitus',
    title: 'Tinnitus',
    icon: '👂',
    accent: '#0072B2',
    tagline: 'A sound that never switches off',
    quote: '[QUOTE NEEDED]',
    quoteBy: '— Name, age',
    stat: '[VERIFY] Around 1 in 7 adults experience tinnitus.',
    source: '[VERIFY] cite source',
    task: 'Listen for your name when the barista calls it.',
    supportTask: 'Same task, with live captions.',
    warning: 'This room plays a continuous high-pitched tone. Please lower your volume before you begin.',
    helped: 'Live captions and a visual "order ready" screen.',
    action: 'Turn on captions and face people when you speak.',
  },
  {
    id: 'schizophrenia',
    title: 'Schizophrenia',
    icon: '💭',
    accent: '#D55E00',
    tagline: 'Concentrating while voices talk over you',
    quote: '[QUOTE NEEDED]',
    quoteBy: '— Name, age',
    stat: '[VERIFY] Many people with schizophrenia hear voices. Most are not violent and are more likely to be victims of violence than perpetrators.',
    source: '[VERIFY] cite source',
    task: 'Fill in a short job application.',
    supportTask: 'Same task, with a calm guide and a quiet space.',
    warning: 'This room includes whispered voices. This is one person’s experience; it varies widely.',
    helped: 'Clear, calm instructions, extra time and a quiet space.',
    action: 'Be patient, speak calmly and give clear instructions.',
  },
  {
    id: 'reflection',
    title: 'Reflection',
    icon: '🌱',
    accent: '#2B2B2E',
    tagline: 'What changed, and what you can do',
    quote: '',
    quoteBy: '',
    stat: '',
    source: '',
    task: '',
    supportTask: '',
    helped: '',
    action: '',
  },
];

export const roomInfo = (id: RoomId): RoomInfo => ROOMS.find((r) => r.id === id)!;

export const COPY = {
  title: 'Through My Eyes',
  subtitle: 'See the struggle, then see the solution.',
  disclaimer: 'A simulation, not the real thing. Experiences vary from person to person.',
  description:
    'Walk through rooms that each simulate a health condition. Try an everyday task, then turn on support and see how small changes make it easier.',
};
