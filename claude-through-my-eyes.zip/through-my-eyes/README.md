# Through My Eyes

*See the struggle, then see the solution.*

A browser-based 3D gallery. Visitors walk a corridor of rooms. In each room they try an everyday task while a health condition is simulated, then they switch on support and see how small changes make the task easier.

Built with **TypeScript + three.js + Vite**. It's a static website: no camera, no headset, no permissions.

## Run it

```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # type-check + production build into dist/
npm run preview    # serve the built site
```

**Deploy:** push to GitHub and import the repo into Vercel or Netlify. Build command `npm run build`, output folder `dist`. No other config needed.

## Controls

| Input | Action |
|---|---|
| W A S D / arrow keys | Move (left/right arrows turn, for keyboard-only users) |
| Drag, or **M** to lock the mouse | Look around (Esc releases the mouse) |
| Click, or **E** / Space | Interact with what's under the cursor / crosshair |
| Click the floor | Walk there |
| ☰ Rooms | Jump to any room (useful when judging) |

**Dev shortcuts** (browser console): `__goto('tunnelVision')` opens a room, and `__complete()` finishes the current task.

## What's done

| Area | Status |
|---|---|
| Lobby, corridor, 6 doorways + reflection room, lighting, plaques | ✅ |
| Movement, collisions, click-to-walk, pointer lock / drag look | ✅ |
| Room flow: intro card → attempt (timed) → "try with support" → results | ✅ |
| HUD: room chip, exit, support toggle, volume, room menu, toasts, captions | ✅ |
| **Colour blindness** room: pick ripe tomatoes, 3 types + severity, filter also applied to the whole page | ✅ |
| **Tunnel vision** room: find your keys, blurred periphery, support = tidy room + high-contrast tag + 3D sound cue | ✅ |
| **Reflection** room: times per room, actions, pledge | ✅ |
| Dyslexia, Face blindness, Tinnitus, Schizophrenia | 🟡 Placeholder rooms. The doorway and full flow work, and the plan is shown on the wall and written as a TODO in each file |

## Project structure

```
src/
  main.ts                 app, render loop, room flow (register new rooms here)
  config.ts               ALL text: room titles, quotes, stats, tasks, sources
  world/                  lobby, corridor, lighting, shared materials and builders
  controls/               first-person movement and collisions
  rooms/
    Room.ts               Room interface + BaseRoom class + RoomContext
    shell.ts              buildShell(): floor, walls, ceiling, lights in one call
    StubRoom.ts           placeholder room
    colourBlindness/      ← reference example
    tunnelVision/
    dyslexia/ faceBlindness/ tinnitus/ schizophrenia/   ← to build
    reflection/
  shaders/                colour blindness (Machado 2009) and tunnel vision
  effects/                post-processing passes + whole-page colour filter
  audio/audioManager.ts   volume, tones, murmur, 3D chimes, clips, speech + captions
  ui/                     HUD, modals, intro card, results, room menu, styles.css
public/audio/             put recorded clips here
```

## How to build a room (e.g. Dyslexia)

1. Open `src/rooms/dyslexia/index.ts`. Read the TODO, which is the plan.
2. Change the class to extend `BaseRoom` instead of `StubRoom`:

```ts
import * as THREE from 'three';
import { BaseRoom } from '../Room';
import { buildShell } from '../shell';
import { rbox } from '../../world/materials';

export class DyslexiaRoom extends BaseRoom {
  constructor() { super('dyslexia'); }

  protected build(): void {
    buildShell(this.scene, this.colliders);              // floor, walls, lights
    const counter = rbox(2, 1, 0.6, '#B88A5A');           // soft rounded box
    counter.position.set(0, 0.5, -2);
    this.scene.add(counter);
    this.colliders.addMesh(counter);                      // can't walk through it
    this.ctx.addClickable(counter, () => this.ctx.complete());
    this.ctx.setTaskText('Order the coffee the waiter asks for');
  }

  setAccessible(on: boolean): void { super.setAccessible(on); /* turn support on/off */ }
  resetTask(): void { /* reset for the second (supported) attempt */ }
  update(dt: number, t: number): void { /* per-frame animation */ }
  exit(): void { /* stop your sounds and timers */ super.exit(); }
}
```

3. Run `npm run dev`, open the console, and run `__goto('dyslexia')`.

### The Room interface

| Method | When it's called | What to do |
|---|---|---|
| `build()` | Room is entered | Build the scene, register clickables, set the task text |
| `update(dt, t)` | Every frame | Animate things |
| `setAccessible(on)` | Before each attempt (`false`, then `true`), and by the Support button afterwards | Turn the support version on or off. **The condition usually stays on.** |
| `resetTask()` | Before the supported attempt, and after each completion in "explore" mode | Reset counters and shuffle positions |
| `exit()` | Leaving the room | Stop sounds and intervals, then call `super.exit()` (which disposes the scene and clears effects) |

### Useful things on `this.ctx`

- `addClickable(obj, fn)`: clickable within 4 m. Use an invisible bigger mesh as a hitbox for tiny objects (see the keys in tunnelVision).
- `complete()`: the attempt is finished. The app handles timing and result cards.
- `toast(msg)`, `setTaskText(text)`, `setRoomControls(htmlElement)` (left-side panel)
- `showPanel(htmlElement)`: centred HTML panel for text-heavy tasks (dyslexia menu, job form). Returns a close function.
- `effects.setColourBlind(type, severity)` and `effects.setTunnel(on, radius)`
- `audio.tone(freq, gain, wobble)`, `audio.murmur()`, `audio.chimeAt(pos)`, `audio.clip('/audio/x.mp3')`, `audio.speak(text, { pitch })` (speech shows captions automatically)

## Design rules (please keep them)

- Palette: walls `#F4EFE6`, floor `#D9CBB3`, charcoal `#2B2B2E`. Room accents are Okabe-Ito colours, always paired with an icon and label.
- Use `rbox()` and `mat()` from `world/materials.ts` for the soft low-poly look. No external models.
- Font: Atkinson Hyperlegible. Large, readable text on signs.
- Never flash more than 3 times a second. No jump scares. Any spoken audio needs captions (use `audio.speak` or call `onCaption`).
- Every new control must be reachable by keyboard.

## Content checklist before the demo

- [ ] Replace every `[QUOTE NEEDED]` in `config.ts` with a real quote, given with permission.
- [ ] Check and cite every `[VERIFY]` stat.
- [ ] Record clips into `public/audio/` (optional; speech synthesis is the fallback).
